export { exportEmotionCard as saveEmotionCard } from './exportEmotionCard';
